package com.example.study_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String passwordConfirm;

    public DBHelper(Context context) {
        super(context, "Userdata.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Userdetails (firstname TEXT, lastname TEXT, email TEXT primary key, password)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int oldVersion, int newVersion) {
        DB.execSQL("drop Table if exists Userdetails");

    }

    public boolean insertuserdata(String firstName, String lastName, String email, String password, String passwordConfirm) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("first Name", firstName);
        contentValues.put("last Name", lastName);
        contentValues.put("Email", email);
        contentValues.put("Password", password);
        contentValues.put("Password Confirm", password);

        // Inserting data into the table
        long result = db.insert("Client details", null, contentValues);

        // Check if the data is inserted successfully
        return result != -1;
    }


    public Cursor getdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("select * from Userdetails ", null);
        return cursor;
    }
}



