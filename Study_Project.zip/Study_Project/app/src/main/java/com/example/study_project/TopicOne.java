package com.example.study_project;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class TopicOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic_one);


        PDFView pdfView=findViewById(R.id.topicone);
        pdfView.fromAsset("TOPIC ONE.pdf").load();
    }
}