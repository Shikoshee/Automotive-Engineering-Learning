package com.example.study_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class Ignition_System extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ignition_system);


        PDFView pdfView=findViewById(R.id.ignition);
        pdfView.fromAsset("IGNITION SYSTEMS.pdf").load();
    }
}