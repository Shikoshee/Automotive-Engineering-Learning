package com.example.study_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class Lumbication_System extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lumbication_system);

        PDFView pdfView=findViewById(R.id.lumbrication);
        pdfView.fromAsset("LUMBLICATION SYSTEM.pdf").load();
    }
}