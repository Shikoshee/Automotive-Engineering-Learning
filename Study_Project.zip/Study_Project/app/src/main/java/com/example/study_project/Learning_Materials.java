
package com.example.study_project;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

public class Learning_Materials extends AppCompatActivity {

    private Button button1,button2,button3,button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning_materials);

        button1 = findViewById(R.id.buttonOne);
        button2 = findViewById(R.id.ignition);
        button3 = findViewById(R.id.buttonTwo);
        button4 = findViewById(R.id.lumbrication);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Learning_Materials.this, TopicOne.class);
                startActivity(intent);
                return ;
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(Learning_Materials.this,Ignition_System.class);
                startActivities(new Intent[]{intent});
                return ;
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(Learning_Materials.this,TopicTwo.class);
                startActivities(new Intent[]{intent});
                return ;
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(Learning_Materials.this,Lumbication_System.class);
                startActivities(new Intent[]{intent});
                return ;
            }
        });


    }
}
