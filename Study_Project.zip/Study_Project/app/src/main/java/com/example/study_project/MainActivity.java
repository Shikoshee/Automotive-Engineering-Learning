package com.example.study_project;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;


import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText emailEditText;
    private EditText passwordEditText;
    private EditText passwordConfirmEditText;
    private Button next;
    private TextView login;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initializeViews();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Login_Page.class);
                startActivity(intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateAndProceed();
            }
        });
    }

    private void initializeViews() {
        progressBar = findViewById(R.id.progressbar);
        firstNameEditText = findViewById(R.id.name);
        lastNameEditText = findViewById(R.id.username);
        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.password);
        passwordConfirmEditText = findViewById(R.id.confirmpassword);
        login = findViewById(R.id.login);
        next = findViewById(R.id.next);
    }

    private void validateAndProceed() {
        String name = firstNameEditText.getText().toString();
        String last = lastNameEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String password1 = passwordEditText.getText().toString();
        String passwordConfirm = passwordConfirmEditText.getText().toString();

        boolean check = validateInfo(name, last, email, password1, passwordConfirm);

        if (check) {
            progressBar.setVisibility(View.VISIBLE); // Show progress bar
            registerUser(name, last, email, password1);
        }
    }

    private boolean validateInfo(String firstName, String lastName, String email, String password, String passwordConfirm) {
        boolean isValid = true;
        if (firstName.isEmpty() || !firstName.matches("[a-zA-Z ]+")) {
            firstNameEditText.setError("Enter a valid Username");
            isValid = false;
        }

        if (lastName.isEmpty() || !lastName.matches("[a-zA-Z ]+")) {
            lastNameEditText.setError("Enter a valid name");
            isValid = false;
        }


        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Enter a valid email address");
            isValid = false;
        }

        if (password.length() < 6) {
            passwordEditText.setError("Minimum 8 characters required");
            isValid = false;
        }

        if (!password.equals(passwordConfirm)) {
            passwordConfirmEditText.setError("Passwords do not match");
            isValid = false;
        }

        return isValid;
    }

    private void registerUser(final String firstName, final String lastName, String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            // Create a User object with the provided data
                            User newUser = new User(user.getDisplayName(), firstName + " " + lastName, user.getEmail(), password);
                            String userId = user.getUid();
                            saveUserInfoToFirestore(firstName, lastName, userId);
                            saveUserToRealtimeDatabase(newUser, userId);
                        } else {
                            progressBar.setVisibility(View.GONE); // Hide progress bar
                            Toast.makeText(MainActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void saveUserInfoToFirestore(String firstName, String lastName, String userId) {
        // Create a map to store user data
        Map<String, Object> user = new HashMap<>();
        user.put("firstName", firstName);
        user.put("lastName", lastName);

        // Add user data to Firestore
        db.collection("users").document(userId)
                .set(user, SetOptions.merge())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "User data saved to Firestore successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Failed to save user data to Firestore.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void saveUserToRealtimeDatabase(User user, String userId) {
        // Get reference to the "users" node in the Firebase Realtime Database
        DatabaseReference usersRef = mDatabase.child("users");
        // Save the user object under the user's UID as the key
        usersRef.child(userId).setValue(user)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(Task<Void> task) {
                        progressBar.setVisibility(View.GONE); // Hide progress bar
                        if (task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "User registered successfully!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, Login_Page.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Failed to save user information to Realtime Database.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


}
